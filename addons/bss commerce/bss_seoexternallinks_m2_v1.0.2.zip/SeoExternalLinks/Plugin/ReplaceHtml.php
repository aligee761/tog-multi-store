<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_SeoExternalLinks
 * @author     Extension Team
 * @copyright  Copyright (c) 2018-2024 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\SeoExternalLinks\Plugin;

use Bss\SeoExternalLinks\Helper\Data;

/**
 * Class ReplaceHtml
 * @package Bss\SeoExternalLinks\Plugin
 */
class ReplaceHtml
{
    /**
     * @var \Bss\SeoExternalLinks\Helper\Data
     */
    protected $dataHelper;

    /**
     * ReplaceHtml constructor.
     * @param Data $dataHelper
     */
    public function __construct(
        \Bss\SeoExternalLinks\Helper\Data $dataHelper
    ) {
        $this->dataHelper = $dataHelper;
    }

    /**
     * @param \Magento\Framework\View\Element\Template $subject
     * @param null $html
     * @return string|string[]|null
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterToHtml(\Magento\Framework\View\Element\Template $subject, $html = null)
    {
        if (!$this->dataHelper->getModelEnable()) {
            return $html;
        }

        if ($html === null || strpos($html, '<a') === false) {
            return $html;
        }

        return $this->dataHelper->addNofollow($html);
    }
}
