# [Release Note](https://bsscommerce.com/magento-2-xml-sitemap-extension.html)

## v1.2.1 (April 25, 2025): 
- Fix bug: The sitemap link in backend grid does not match the store view URL.