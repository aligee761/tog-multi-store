<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\ProductFeed\Model\ResourceModel\Reports;

use DateTime;
use Exception;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface as FetchStrategy;
use Magento\Framework\Data\Collection\EntityFactoryInterface as EntityFactory;
use Magento\Framework\DB\Select;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult;
use Mageplaza\ProductFeed\Helper\Data;
use Mageplaza\ProductFeed\Model\ResourceModel\Reports as ReportsResource;
use Psr\Log\LoggerInterface as Logger;
use Zend_Db_Expr;

/**
 * Class Collection
 * @package Mageplaza\ProductFeed\Model\ResourceModel\Reports
 */
class Collection extends SearchResult
{
    /**
     * @var array
     */
    protected $_selectedColumns = [];

    /**
     * ID Field Name
     *
     * @var string
     */
    protected $_idFieldName = 'report_id';

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'mageplaza_productfeed_reports_collection';

    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'reports_collection';

    /**
     * @var array
     */
    protected $_dateRange = ['from' => null, 'to' => null];

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var Data
     */
    protected $helperData;

    /**
     * Collection Constructor.
     *
     * @param EntityFactory $entityFactory
     * @param Logger $logger
     * @param FetchStrategy $fetchStrategy
     * @param EventManager $eventManager
     * @param RequestInterface $request
     * @param Data $helperData
     * @param $mainTable
     * @param $resourceModel
     * @param $identifierName
     * @param $connectionName
     *
     * @throws LocalizedException
     */
    public function __construct(
        EntityFactory $entityFactory,
        Logger $logger,
        FetchStrategy $fetchStrategy,
        EventManager $eventManager,
        RequestInterface $request,
        Data $helperData,
        $mainTable = 'mageplaza_productfeed_reports',
        $resourceModel = ReportsResource::class,
        $identifierName = null,
        $connectionName = null
    ) {
        $this->request    = $request;
        $this->helperData = $helperData;

        parent::__construct(
            $entityFactory,
            $logger,
            $fetchStrategy,
            $eventManager,
            $mainTable,
            $resourceModel,
            $identifierName,
            $connectionName
        );
    }

    /**
     * Init collection select
     *
     * @return $this
     */
    protected function _initSelect()
    {
        $tableName = $this->getMainTable();

        $this->getSelect()->from(['main_table' => $tableName], $this->_getSelectedColumns())
            ->joinLeft(
                ['product_feed' => $this->getTable('mageplaza_productfeed_feed')],
                'main_table.feed_id = product_feed.feed_id',
                []
            )->joinLeft(
                ['order' => $this->getTable('sales_order')],
                'main_table.order_id = order.entity_id AND order.status NOT LIKE \'closed\'',
                []
            )->group('main_table.feed_id');

        return $this;
    }

    /**
     * Retrieve selected columns
     *
     * @return array
     */
    protected function _getSelectedColumns()
    {

            $this->_selectedColumns = [
                'feed_id'          => 'main_table.feed_id',
                'name'             => 'product_feed.name',
                'ordered_quantity' => new Zend_Db_Expr('SUM(main_table.ordered_quantity)'),
                'order_count'      => new Zend_Db_Expr('COUNT(DISTINCT order.entity_id)'),
                'feed_revenue'     => new Zend_Db_Expr('SUM(main_table.revenue)'),
                'feed_refunded'    => new Zend_Db_Expr('SUM(main_table.refunded)'),
                'feed_discount'    => new Zend_Db_Expr('SUM(main_table.discount)'),
                'feed_tax'         => new Zend_Db_Expr('SUM(main_table.tax)'),
                'click'            => 'product_feed.click',
                'impression'       => 'product_feed.impression',
                'ctr'              => 'product_feed.ctr'
            ];


        return $this->_selectedColumns;
    }

    /**
     * @param array|string $field
     * @param null $condition
     *
     * @return $this|SearchResult
     */
    public function addFieldToFilter($field, $condition = null)
    {
        if (isset($condition['like'])) {
            $this->getSelect()->having("{$field} like '{$condition['like']}'");
        }
        if (isset($condition['gteq'])) {
            $this->getSelect()->having("{$field} >= {$condition['gteq']}");
        }
        if (isset($condition['lteq'])) {
            $this->getSelect()->having("{$field} <= {$condition['lteq']}");
        }

        return $this;
    }

    /**
     * @return $this|SearchResult
     * @throws Exception
     */
    protected function _beforeLoad()
    {
        parent::_beforeLoad();

        $this->_applyDateRangeFilter($this->_dateRange['from'], $this->_dateRange['to']);

        return $this;
    }

    /**
     * @return Select
     */
    public function getSelectCountSql()
    {
        $this->_renderFilters();
        $select = clone $this->getSelect();
        $select->reset(Select::ORDER);

        return $this->getConnection()->select()->from($select, 'COUNT(*)');
    }

    /**
     * @param null $fromDate
     * @param null $toDate
     *
     * @return $this
     * @throws Exception
     */
    protected function _applyDateRangeFilter($fromDate = null, $toDate = null)
    {
        [$fromDate, $toDate] = $this->getDateRange($fromDate, $toDate);

        if ($fromDate !== null) {
            $this->getSelect()->where('main_table.created_at >= ?', $fromDate);
        }
        if ($toDate !== null) {
            $this->getSelect()->where('main_table.created_at <= ?', $toDate);
        }

        return $this;
    }

    /**
     * @param null $fromDate
     * @param null $toDate
     * @param null $format
     *
     * @return array
     * @throws Exception
     */
    protected function getDateRange($fromDate = null, $toDate = null, $format = null)
    {
        if ($fromDate === null) {
            $fromDate = isset($this->request->getParam('mpFilter')['startDate'])
                ? $this->request->getParam('mpFilter')['startDate']
                : $this->request->getParam('startDate');
            if ($fromDate && $format) {
                $fromDate = (new DateTime($fromDate))->format($format);
            }
        }
        if ($toDate === null) {
            $toDate = isset($this->request->getParam('mpFilter')['endDate'])
                ? $this->request->getParam('mpFilter')['endDate']
                : $this->request->getParam('endDate');
            if ($toDate && $format) {
                $toDate = (new DateTime($toDate))->format($format);
            }
        }
        if ($toDate === null || $fromDate === null) {
            [$fromDate, $toDate] = $this->helperData->getDateRange($format);
        }

        return [$fromDate, $toDate];
    }
}
