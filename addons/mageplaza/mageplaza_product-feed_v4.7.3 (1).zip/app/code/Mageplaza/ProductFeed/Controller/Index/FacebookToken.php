<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\ProductFeed\Controller\Index;

use Exception;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\HTTP\Adapter\CurlFactory;
use Magento\Framework\Session\SessionManagerInterface;
use Mageplaza\ProductFeed\Helper\Data as HelperData;

/**
 * Class FacebookToken
 * @package Mageplaza\ProductFeed\Controller\Index
 */
class FacebookToken extends Action
{
    /**
     * @var CurlFactory
     */
    protected $curlFactory;

    /**
     * @var HelperData
     */
    protected $helperData;

    /**
     * @var SessionManagerInterface
     */
    protected $session;

    /**
     * FacebookToken constructor.
     *
     * @param Context $context
     * @param CurlFactory $curlFactory
     * @param HelperData $helperData
     * @param SessionManagerInterface $session
     */
    public function __construct(
        Context $context,
        CurlFactory $curlFactory,
        HelperData $helperData,
        SessionManagerInterface $session
    ) {
        $this->curlFactory = $curlFactory;
        $this->helperData  = $helperData;
        $this->session     = $session;

        parent::__construct($context);
    }

    /**
     * @return ResponseInterface|ResultInterface
     * @throws LocalizedException
     */
    public function execute()
    {
        $code = $this->getRequest()->getParam('code');
        if ($code) {
            $clientId = $this->helperData->getClientId('facebook_api');
            if (!$clientId) {
                $this->session->setMpProductFeedErrorMessage('Please fill Client Id!');

                return $this->_redirect('mpproductfeed/');
            }

            $clientSecret = $this->helperData->getClientSecret('facebook_api');
            if (!$clientSecret) {
                $this->session->setMpProductFeedErrorMessage('Please fill Client Secret');

                return $this->_redirect('mpproductfeed/');
            }

            $redirectURI = $this->helperData->getOAuthRedirectURIs();
            if (!$redirectURI) {
                $this->session->setMpProductFeedErrorMessage(__('Please fill Authorized redirect URIs'));

                return $this->_redirect('mpproductfeed/');
            }

            $catalogId = $this->helperData->getCatalogId();
            if (!$catalogId) {
                $this->session->setMpProductFeedErrorMessage(__('Please fill Catalog ID'));

                return $this->_redirect('mpproductfeed/');
            }

            try {
                $url = 'https://graph.facebook.com/v19.0/oauth/access_token?';
                $url .= 'client_id=' . $clientId;
                $url .= '&client_secret=' . $clientSecret;
                $url .= '&redirect_uri=' . $redirectURI;
                $url .= '&code=' . $code;

                $resp = $this->requestData($url);

                if ($resp && is_array($resp) && isset($resp['access_token'])) {
                    $this->helperData->saveAPIData($resp, false, 'facebook_api');
                    $this->session->setMpProductFeedSuccessMessage(
                        __('The Access Token has been saved successfully. You can close this window, then clean cache and refresh configuration page.')
                    );
                } else {
                    $this->session->setMpProductFeedErrorMessage(__('Invalid access token. Please try again!'));
                }
            } catch (Exception $e) {
                $this->session->setMpProductFeedErrorMessage($e->getMessage());
            }
        } else {
            $this->session->setMpProductFeedErrorMessage(__('Grant token not found!'));
        }

        return $this->_redirect('mpproductfeed/');
    }

    /**
     * @param string $url
     *
     * @return array|mixed
     * @throws Exception
     */
    public function requestData($url)
    {
        $httpAdapter = $this->curlFactory->create();

        $httpAdapter->write("GET", $url);
        $result   = $httpAdapter->read();
        $response = HelperData::extractBody($result);
        $response = HelperData::jsonDecode($response);

        if (isset($response['error'])) {
            $message = isset($response['error_description']) ? $response['error_description']
                : __('Something went wrong while syncing feed. Please try again.');
            throw new Exception($message);
        }
        $httpAdapter->close();

        return $response;
    }
}
