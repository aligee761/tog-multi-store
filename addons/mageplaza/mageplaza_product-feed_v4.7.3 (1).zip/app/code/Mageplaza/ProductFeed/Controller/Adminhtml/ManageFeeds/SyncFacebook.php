<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\ProductFeed\Controller\Adminhtml\ManageFeeds;

use Exception;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Registry;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Mageplaza\ProductFeed\Controller\Adminhtml\AbstractManageFeeds;
use Mageplaza\ProductFeed\Helper\Data;
use Mageplaza\ProductFeed\Model\Config\Source\Status;
use Mageplaza\ProductFeed\Model\FeedFactory;
use Mageplaza\ProductFeed\Model\HistoryFactory;
use Psr\Log\LoggerInterface;

/**
 * Class SyncFacebook
 * @package Mageplaza\ProductFeed\Controller\Adminhtml\ManageFeeds
 */
class SyncFacebook extends AbstractManageFeeds
{
    /**
     * @var JsonFactory
     */
    protected $jsonFactory;

    /**
     * @var Data
     */
    protected $helperData;

    /**
     * @var HistoryFactory
     */
    protected $historyFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var DateTime
     */
    protected $dateTime;


    /**
     * SyncFacebook constructor.
     *
     * @param FeedFactory $feedFactory
     * @param JsonFactory $jsonFactory
     * @param Data $helperData
     * @param HistoryFactory $historyFactory
     * @param LoggerInterface $logger
     * @param DateTime $dateTime
     * @param Registry $coreRegistry
     * @param Context $context
     */
    public function __construct(
        FeedFactory $feedFactory,
        JsonFactory $jsonFactory,
        Data $helperData,
        HistoryFactory $historyFactory,
        DateTime $dateTime,
        LoggerInterface $logger,
        Registry $coreRegistry,
        Context $context
    ) {
        $this->jsonFactory    = $jsonFactory;
        $this->helperData     = $helperData;
        $this->historyFactory = $historyFactory;
        $this->logger         = $logger;
        $this->dateTime       = $dateTime;

        parent::__construct($feedFactory, $coreRegistry, $context);
    }

    /**
     * @return ResponseInterface|Json|ResultInterface
     * @throws Exception
     */
    public function execute()
    {
        $feed       = $this->initFeed(true);
        $resultJson = $this->jsonFactory->create();

        if (!$this->helperData->isEnabled()) {
            return $resultJson->setData([
                'success' => false,
                'message' => __('Please enable module to sync.')
            ]);
        }
        if (!$feed->getStatus()) {
            return $resultJson->setData([
                'success' => false,
                'message' => __('Please enable the feed to sync.')
            ]);
        }

        try {
            $response = $this->helperData->SyncFacebookFeed($feed);
            if ($response['id']) {
                $result = [
                    'success' => true,
                    'message' => __('%1 feed sync successfully', $feed->getName()),
                    'id'      => $response['id']
                ];

                $history = $this->historyFactory->create();
                $history->setData([
                    'feed_id'         => $feed->getId(),
                    'feed_name'       => $feed->getName(),
                    'status'          => Status::SUCCESS,
                    'type'            => 'sync',
                    'product_count'   => 1,
                    'success_message' => __('%1 feed sync successfully', $feed->getName())
                ])->save();
            }
        } catch (Exception $e) {
            $history = $this->historyFactory->create();
            $history->setData([
                'feed_id'       => $feed->getId(),
                'feed_name'     => $feed->getName(),
                'status'        => Status::ERROR,
                'type'          => 'sync',
                'product_count' => 0,
                'error_message' => __('%1 feed sync fail', $feed->getName())
            ])->save();
            $result = [
                'success' => false,
                'message' => __('Something went wrong while sync Facebook Feed. Please try again.')
            ];
        }

        return $resultJson->setData($result);
    }
}
