<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\ProductFeed\Block\Adminhtml\System\Config;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Button;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Exception\LocalizedException;
use Mageplaza\ProductFeed\Helper\Data as HelperData;

/**
 * Class FacebookAccessToken
 * @package Mageplaza\ProductFeed\Block\Adminhtml\System\Config
 */
class FacebookAccessToken extends Field
{
    /**
     * @var HelperData
     */
    protected $helperData;

    /**
     * @var string
     */
    protected $_template = 'Mageplaza_ProductFeed::system/config/facebook_access_token.phtml';

    /**
     * FacebookAccessToken constructor.
     *
     * @param Context $context
     * @param HelperData $helperData
     * @param array $data
     */
    public function __construct(
        Context $context,
        HelperData $helperData,
        array $data = []
    ) {
        $this->helperData = $helperData;

        parent::__construct($context, $data);
    }

    /**
     * Remove scope label
     *
     * @param AbstractElement $element
     *
     * @return string
     */
    public function render(AbstractElement $element)
    {
        $element->unsScope()->unsCanUseWebsiteValue()->unsCanUseDefaultValue();

        return parent::render($element);
    }

    /**
     * Return element html
     *
     * @param AbstractElement $element
     *
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element)
    {
        return $this->_toHtml();
    }

    /**
     * @return string
     */
    public function getButtonHtml()
    {
        try {
            /** @var Button $button */
            $button = $this->getLayout()->createBlock(
                Button::class
            )->setData(
                [
                    'id'    => 'fb_access_token_button',
                    'label' => __('Get Access Token'),
                    'class' => 'primary',
                ]
            );
        } catch (LocalizedException $e) {
            $this->_logger->critical($e->getMessage());

            return '';
        }


        return $button->toHtml();
    }

    /**
     * @return string
     */
    public function getFBAccessTokenUrl()
    {
        $url = 'https://www.facebook.com/v19.0/dialog/oauth?';
        $url .= 'client_id=' . $this->helperData->getClientId('facebook_api');
        $url .= '&redirect_uri=' . $this->getValidOAuthRedirectURIs();
        $url .= '&scope=public_profile,email,catalog_management';

        return $url;
    }

    /**
     * @return string
     */
    public function getValidOAuthRedirectURIs()
    {
        $url = '';
        try {
            $url = $this->helperData->getValidOAuthRedirectURIs();
        } catch (LocalizedException $e) {
            $this->_logger->critical($e->getMessage());
        }

        return $url;
    }
}
