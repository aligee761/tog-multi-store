<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\ProductFeed\Ui\Component\Listing\Columns;

use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class File
 * @package Mageplaza\ProductFeed\Ui\Component\Listing\Columns
 */
class Render extends Column
{
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                if (isset($item[$this->getData('name')])) {
                    if ($item['name'] && $item['id_field_name'] === 'feed_id') {
                        $item['name'] = strlen($item['name']) > 40
                            ? substr($item['name'], 0, 39) . '...' : $item['name'];
                    }
                    if (isset($item['ordered_quantity'])) {
                        $item['ordered_quantity'] = round($item['ordered_quantity']);
                    }
                }
            }
        }

        return $dataSource;
    }
}
