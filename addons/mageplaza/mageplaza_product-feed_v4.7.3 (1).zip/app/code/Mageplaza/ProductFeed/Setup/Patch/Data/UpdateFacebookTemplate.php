<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */
declare(strict_types=1);

namespace Mageplaza\ProductFeed\Setup\Patch\Data;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\Patch\PatchRevertableInterface;

/**
 * Patch is mechanism, that allows to do atomic upgrade data changes
 */
class UpdateFacebookTemplate implements DataPatchInterface, PatchRevertableInterface
{
    /**
     * @var ModuleDataSetupInterface $moduleDataSetup
     */
    private $moduleDataSetup;

    /**
     * UpdateFacebookTemplate Constructor.
     *
     * @param ModuleDataSetupInterface $moduleDataSetup
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function apply()
    {
        $templateHtml = <<<XML
<?xml version="1.0" encoding="utf-8" ?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">
  <channel>
    <title>Facebook Feed</title>
    <link>{{ store.base_url }}</link>
    <description>This is description</description>
    {% for product in products %}
    <item>
      <g:id><![CDATA[{{ product.sku }}]]></g:id>
      <g:title><![CDATA[{{ product.name | strip_html | truncatewords: \'150\' }}]]></g:title>
      <g:description><![CDATA[{{ product.description | strip_html | truncatewords: \'600\' }}]]></g:description>
      <link><![CDATA[{{ product.link }}]]></link>
      <g:image_link><![CDATA[{{ product.image_link }}]]></g:image_link>
      {% for image in product.images %}
        <g:additional_image_link><![CDATA[{{ image.url }}]]></g:additional_image_link>
      {% endfor %}
      <g:condition>New</g:condition>
      <g:availability>{{ product.quantity_and_stock_status }}</g:availability>
      <g:price>{{ product.final_price | price }}</g:price>
      <g:google_product_category><![CDATA[{{ product.mapping }}]]></g:google_product_category>
      <g:product_type><![CDATA[{{ product.category_path }}]]></g:product_type>
      <g:brand><![CDATA[{{ product.manufacturer | ifEmpty: "Default Brand" }}]]></g:brand>
    </item>
    {% endfor %}
  </channel>
</rss>
XML;

        $this->moduleDataSetup->getConnection()->update(
            $this->moduleDataSetup->getTable('mageplaza_productfeed_defaulttemplate'),
            [
                'file_type'     => 'xml,csv,tsv,xlsx',
                'template_html' => $templateHtml
            ],
            ['name LIKE ?' => 'fb']
        );
    }

    /**
     * @inheritdoc
     */
    public function revert()
    {
    }

    /**
     * @inheritdoc
     */
    public function getAliases()
    {
        return [];
    }

    /**
     * @inheritdoc
     */
    public static function getDependencies()
    {
        return [];
    }
}
