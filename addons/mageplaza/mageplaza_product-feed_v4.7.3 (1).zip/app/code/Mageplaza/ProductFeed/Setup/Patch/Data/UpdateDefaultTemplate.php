<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */
declare(strict_types=1);

namespace Mageplaza\ProductFeed\Setup\Patch\Data;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\Patch\PatchRevertableInterface;
use Mageplaza\ProductFeed\Model\DefaultTemplate;
use Mageplaza\ProductFeed\Model\ResourceModel\DefaultTemplate\CollectionFactory;

/**
 * Patch is mechanism, that allows to do atomic upgrade data changes
 */
class UpdateDefaultTemplate implements
    DataPatchInterface,
    PatchRevertableInterface
{
    /**
     * @var ModuleDataSetupInterface $moduleDataSetup
     */
    private $moduleDataSetup;

    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CollectionFactory $collectionFactory
    ) {
        $this->moduleDataSetup   = $moduleDataSetup;
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function apply()
    {
        $this->titleTemplate();

        $sampleTemplates = [];

        /* ebay xml template */
        $templateHtml = <<<XML
<?xml version="1.0" encoding="utf-8" ?>
<productRequest>
{% for product in products %}
    <SKU><![CDATA[{{ product.sku }}]]></SKU>
    <productInformation localizedFor="{{ store.locale_code }}">
        <title><![CDATA[{{ product.name | strip_html | truncatewords: \'150\' }}]]></title>
        <description>
            <productDescription><![CDATA[{{ product.description | strip_html | truncatewords: \'600\' }}]]></productDescription>
        </description>
        <pictureURL><![CDATA[{{ product.image_link }}]]></pictureURL>
        <conditionInfo>
            <condition>New</condition>
        </conditionInfo>
    </productInformation>
{% endfor %}
</productRequest>
XML;

        $this->moduleDataSetup->getConnection()->update(
            $this->moduleDataSetup->getTable('mageplaza_productfeed_defaulttemplate'),
            ['template_html' => $templateHtml],
            ['name LIKE ?' => 'ebay']
        );

        /* custom template */
        $sampleTemplates[] = [
            'name'           => 'custom',
            'title'          => 'Custom',
            'file_type'      => 'xml,csv,txt,tsv,xls',
            'template_html'  => null,
            'field_separate' => null,
            'field_around'   => null,
            'include_header' => null,
            'fields_map'     => null
            ];

        $this->moduleDataSetup->getConnection()->insertOnDuplicate(
            $this->moduleDataSetup->getTable('mageplaza_productfeed_defaulttemplate'),
            $sampleTemplates
        );
    }

    /**
     * @return void
     * @throws \Exception
     */
    protected function titleTemplate()
    {
        $collectionFactory  = $this->collectionFactory->create();
        /** @var DefaultTemplate $template */
        foreach ($collectionFactory as $template) {
            switch ($template->getName()) {
                case 'google_shopping_xml':
                    $template->setName('google_shopping')->setTitle('Google Shopping');
                    break;
                case 'google_shopping_review_xml':
                    $template->setName('google_shopping_review')->setTitle('Google Shopping Review');
                    break;
                case 'amazon_inventory_xml':
                    $template->setName('amazon_inventory')->setTitle('Amazon Inventory');
                    break;
                case 'amazon_marketplace_xml':
                    $template->setName('amazon_marketplace')->setTitle('Amazon Marketplace');
                    break;
                case 'fb_csv':
                    $template->setName('fb')->setTitle('Facebook');
                    break;
                case 'ebay_csv':
                    $template->setName('ebay')->setFileType('csv,xml')->setTitle('Ebay');
                    break;
            }
            $template->save();
        }
    }

    /**
     * @inheritdoc
     */
    public function revert()
    {
    }

    /**
     * @inheritdoc
     */
    public function getAliases()
    {
        return [];
    }

    /**
     * @inheritdoc
     */
    public static function getDependencies()
    {
        return [];
    }
}
