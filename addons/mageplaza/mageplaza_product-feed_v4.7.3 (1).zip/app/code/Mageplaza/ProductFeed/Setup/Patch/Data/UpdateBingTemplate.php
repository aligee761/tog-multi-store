<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */
declare(strict_types=1);

namespace Mageplaza\ProductFeed\Setup\Patch\Data;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

/**
 * Patch is mechanism, that allows to do atomic upgrade data changes
 *
 * Class DefaultTemplate
 * @package Mageplaza\ProductFeed\Setup\Patch\Data
 */
class UpdateBingTemplate implements DataPatchInterface
{
    /**
     * @var ModuleDataSetupInterface $moduleDataSetup
     */
    private $moduleDataSetup;

    /**
     * UpdateBingTemplate Constructor.
     *
     * @param ModuleDataSetupInterface $moduleDataSetup
     */
    public function __construct(ModuleDataSetupInterface $moduleDataSetup)
    {
        $this->moduleDataSetup = $moduleDataSetup;
    }

    /**
     * Do Upgrade
     *
     * @return void
     */
    public function apply()
    {
        $sampleTemplates = [
            'name'           => 'bing',
            'title'          => 'Bing Ads',
            'file_type'      => 'csv',
            'template_html'  => '',
            'field_separate' => 'comma',
            'field_around'   => 'quotes',
            'include_header' => 1,
            'fields_map'     => '{"1535359311257_257":{"col_name":"id","col_type":"attribute","col_attr_val":"sku","col_pattern_val":"","col_val":"{{ product.sku }}"},"1535359336738_738":{"col_name":"status","col_type":"attribute","col_attr_val":"quantity_and_stock_status","col_pattern_val":"","col_val":"{{ product.quantity_and_stock_status }}"},"1535359394224_224":{"col_name":"description","col_type":"attribute","col_attr_val":"description","col_pattern_val":"","col_val":"{{ product.description | strip_html }}","modifiers":{"1535359411350_350":{"value":"strip_html"}}},"1707189839534_534":{"col_name":"image_link","col_type":"attribute","col_attr_val":"image_link","col_pattern_val":"","col_val":"{{ product.image_link }}"},"1535359434434_434":{"col_name":"link","col_type":"attribute","col_attr_val":"link","col_pattern_val":"","col_val":"{{ product.link }}"},"1535359500069_69":{"col_name":"title","col_type":"attribute","col_attr_val":"name","col_pattern_val":"","col_val":"{{ product.name }}"},"1535359506883_883":{"col_name":"price","col_type":"attribute","col_attr_val":"price","col_pattern_val":"","col_val":"{{ product.price }}"},"1535359521867_867":{"col_name":"brand","col_type":"attribute","col_attr_val":"manufacturer","col_pattern_val":"","col_val":"{{ product.manufacturer | ifEmpty: \'Example\' }}","modifiers":{"1535359566895_895":{"value":"ifEmpty","params":["Example"]}}},"1707189865995_995":{"col_name":"condition","col_type":"pattern","col_attr_val":"0","col_pattern_val":"new","col_val":""},"1707189879419_419":{"col_name":"mnp","col_type":"attribute","col_attr_val":"sku","col_pattern_val":"","col_val":"{{ product.sku }}"}}'
        ];

        $this->moduleDataSetup->getConnection()->insertOnDuplicate(
            $this->moduleDataSetup->getTable('mageplaza_productfeed_defaulttemplate'),
            $sampleTemplates
        );
    }

    /**
     * @inheritdoc
     */
    public function getAliases()
    {
        return [];
    }

    /**
     * @inheritdoc
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * @return string
     */
    public static function getVersion()
    {
        return '1.0.7';
    }
}
