/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */
define([
    'jquery',
    'mage/translate',
    'Magento_Ui/js/modal/modal',
    'Magento_Ui/js/modal/confirm',
    'Magento_Ui/js/modal/alert'
], function ($, $t, modal, uiConfirm, uiAlert) {
    "use strict";

    $.widget('mageplaza.syncFacebookFeed', {
        /**
         * This method constructs a new widget.
         * @private
         */
        _create: function () {
            this.initSyncFacebookFeedsObs();
        },

        initSyncFacebookFeedsObs: function () {
            var self = this;

            this.element.click(function () {
                self.initProcessModal();
                self.mpStopRequest = false;
                var prepareSyncEl  = $('#mp_sync_feed_data'),
                    syncResult     = $('#sync_result');

                prepareSyncEl.find('.loader-small').show();

                $.ajax({
                    url: self.options.url,
                    method: 'POST',
                    data: {form_key: window.FORM_KEY, step: 'prepare_sync'},
                    success: function (res) {
                        if (!res.success) {
                            self.showErrorMessage(res.message ? res.message : res);
                            self.syncFacebookFeed.closeModal();
                            return;
                        }
                        prepareSyncEl.find('.index-icon').html('<i class="fa fa-check" style="color: green"></i>');
                        prepareSyncEl.find('.loader-small').hide();
                        syncResult.find('.index-icon').html('<i class="fa fa-check" style="color: green"></i>');
                        syncResult.find('.loader-small').hide();
                        self.syncFacebookFeed.setTitle($t('Sync Completed'));
                        self.syncFacebookFeed.buttons.first().text($t('Ok'));
                        self.syncFacebookFeed.buttons.first().data('mpIsComplete', true);
                    },
                    error: function (e) {
                        self.mpStopRequest = true;
                        self.showErrorMessage(e.responseText);
                        self.syncFacebookFeed.closeModal();
                    }
                });
            });
        },
        initProcessModal: function () {
            var html = '', options, self = this;

            html += '<div>';
            html +=
                '<div class="mp-index-item" id="mp_sync_feed_data">' +
                '   <div class="index-icon" style="display: inline-block; width: 20px;"></div>' +
                '   <div class="loader-small"></div>' +
                '   <span class="index-title">' + $t('Syncing') + '</span>' +
                '   <span class="index-process"></span>' +
                '</div>';
            html +=
                '<div class="mp-index-item" id="sync_result">' +
                '   <div class="index-icon" style="display: inline-block; width: 20px;"></div>' +
                '   <div class="loader-small"></div>' +
                '   <span class="index-title">' + $t('Finished') + '</span>' +
                '   <span class="index-process"></span> ' +
                '</div>';

            html += '</div>';
            options               = {
                'type': 'popup',
                'modalClass': 'mp-sync-popup',
                'title': $t('Syncing facebook feed...'),
                'responsive': true,
                'innerScroll': true,
                'buttons': [{
                    text: $t('Cancel'),
                    class: 'action',
                    click: function () {
                        var that = this;

                        if (this.buttons.first().data('mpIsComplete')) {
                            that.closeModal();
                        } else {
                            uiConfirm({
                                content: $t('Are you sure to stop?'),
                                actions: {
                                    /** @inheritdoc */
                                    confirm: function () {
                                        self.mpStopRequest = true;
                                        that.closeModal();
                                    }
                                }
                            });
                        }
                    }
                }],
                'modalCloseBtnHandler': function () {
                    self.mpStopRequest = true;
                    this.closeModal();
                }
            };
            this.syncFacebookFeed = modal(options, html);
            this.syncFacebookFeed.openModal().on('modalclosed', function () {
                $('.mp-sync-popup').remove();
            });
        },
        showErrorMessage: function (mess) {
            uiAlert({
                content: mess
            });
        }
    });

    return $.mageplaza.syncFacebookFeed;
});
