/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductFeed
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define([
    'jquery',
    'underscore',
    'Magento_Ui/js/grid/provider',
    'uiRegistry',
    'mage/translate',
    'chartBundle'
], function ($, _, Provider, Registry, $t) {
    'use strict';

    return Provider.extend({
        /**
         * @param data
         * @returns {*}
         */
        processData: function (data) {
            this.getReportData(data);

            return this._super(data);
        },
        getReportData: function (data) {
            var self = this;

            self.drawChart(data);

            $('.mp-bar-chart-btn').on('click', function () {
                $('.mp-bar-chart-btn').css('background', 'linear-gradient(179deg, #4B91F7 0%, #367AF6 100%)');
                $('.mp-pie-chart-btn').css('background', '#6E6D70');
                $(".mp-bar-chart").show();
                $(".mp-pie-chart").hide();
            });
            $('.mp-pie-chart-btn').on('click', function () {
                $('.mp-pie-chart-btn').css('background', 'linear-gradient(179deg, #4B91F7 0%, #367AF6 100%)');
                $('.mp-bar-chart-btn').css('background', '#6E6D70');
                $(".mp-bar-chart").hide();
                $(".mp-pie-chart").show();
            });
        },
        drawChart: function (data) {
            var items        = data.items,
                labels       = [],
                revenue      = [],
                totalRevenue = 0,
                totalRefund = 0,
                totalAllFeedRevenue = 0,
                totalCTR = 0,
                ctr          = [];

            _.each(items, function (record) {
                labels.push(record.feed_name);
                totalRevenue += parseFloat(record.feed_revenue.replace('$', ''));
                totalRefund += parseFloat(record.feed_refunded.replace('$', ''));
                totalCTR += parseFloat(record.ctr.replace('%', ''));
                ctr.push((parseFloat(record.ctr.replace('%', '')) / totalCTR * 100).toFixed(2));
            });
            totalAllFeedRevenue = totalRevenue - totalRefund;
            if (totalAllFeedRevenue > 0) {
                _.each(items, function (record) {
                    if ((record.feed_revenue.replace('$', '') - record.feed_refunded.replace('$', '')) > 0) {
                        revenue.push(((record.feed_revenue.replace('$', '') - record.feed_refunded.replace('$', '')) / totalAllFeedRevenue * 100).toFixed(2));
                    }
                });
            }

            if (totalCTR === 0) {
                ctr = null;
            }

            var pieChart         = $("#reportChartPie"),
                CTRPieChart      = $("#reportCTRChartPie"),
                barChart         = $("#reportChartBar"),
                CTRBarChart      = $("#reportCTRChartBar"),
                charContainer    = $('.chart-container'),
                backgroundColors = [
                    '#4285f4', '#ea4335', '#fbbc04', '#34a853', '#ff6d01',
                    '#46bdc6', '#7baaf7', '#f07b72', '#fcd04f', '#71c287',
                    '#ff994d', '#7ed1d7', '#b3cefb', '#f7b4ae', '#fde49b',
                    '#aedcba', '#ffc599', '#b5e5e8', '#ecf3fe', '#fdeceb'
                ];

            if (typeof window.pieChart !== 'undefined' && typeof window.pieChart.destroy === 'function') {
                window.pieChart.destroy();
            }
            if (typeof window.barChart !== 'undefined' && typeof window.barChart.destroy === 'function') {
                window.barChart.destroy();
            }
            if (typeof window.CTRPieChart !== 'undefined' && typeof window.CTRPieChart.destroy === 'function') {
                window.CTRPieChart.destroy();
            }
            if (typeof window.CTRBarChart !== 'undefined' && typeof window.CTRBarChart.destroy === 'function') {
                window.CTRBarChart.destroy();
            }
            $('.mp-feed-report-message').remove();
            charContainer.show();
            if (items.length === 0) {
                $('.mp-feed-report-message').remove();
                charContainer.hide();
                charContainer.after('<div class="mp-feed-report-message"><p' +
                    '>' + $.mage.__("There is no data to display for this report.") + '</p></div>');
            } else {
                if (totalAllFeedRevenue) {
                    $('.mp-feed-revenue .mp-feed-report-message').remove();
                    window.pieChart = new window.Chart(pieChart, {
                        type: 'pie',
                        data: {
                            labels: labels,
                            datasets: [
                                {
                                    data: revenue,
                                    fill: true,
                                    backgroundColor: backgroundColors,
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            legend: {
                                display: true,
                                position: 'right'
                            },
                            tooltips: {
                                mode: 'index',
                                callbacks: {
                                    label: function (tooltipItem, data) {
                                        var dataset      = data.datasets[tooltipItem.datasetIndex],
                                            currentValue = dataset.data[tooltipItem.index];

                                        return currentValue + '%';
                                    }
                                }
                            }
                        }
                    });

                    window.barChart = new window.Chart(barChart, {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [
                                {
                                    data: revenue,
                                    fill: false,
                                    yAxisID: 'y-axis-2',
                                    backgroundColor: '#4185F4',
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            labels: {
                                fontColor: "#000000",
                                fontSize: 12
                            },
                            legend: {
                                display: false
                            },
                            tooltips: {
                                mode: 'index',
                                callbacks: {
                                    label: function (tooltipItem, data) {
                                        var dataset      = data.datasets[tooltipItem.datasetIndex],
                                            currentValue = dataset.data[tooltipItem.index];

                                        return currentValue + '%';
                                    },
                                    title: function () {
                                        return '';
                                    }
                                }
                            },
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero: true
                                    },
                                    id: 'y-axis-2'
                                }],
                                xAxes: [{
                                    ticks: {
                                        fontColor: '#000000',
                                        beginAtZero: true
                                    }
                                }]
                            }
                        }
                    });
                    $('.mp-report-name').css('display', 'block');
                } else {
                    $('.mp-feed-revenue').append('<div class="mp-feed-report-message"><p' +
                        '>' + $.mage.__("There is no data to display for this report.") + '</p></div>');
                }
                if (ctr) {
                    $('.mp-feed-ctr .mp-feed-report-message').remove();
                    window.CTRPieChart = new window.Chart(CTRPieChart, {
                        type: 'pie',
                        data: {
                            labels: labels,
                            datasets: [
                                {
                                    data: ctr,
                                    fill: true,
                                    backgroundColor: backgroundColors,
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            legend: {
                                display: true,
                                position: 'right'
                            },
                            tooltips: {
                                mode: 'index',
                                callbacks: {
                                    label: function (tooltipItem, data) {
                                        var dataset      = data.datasets[tooltipItem.datasetIndex],
                                            currentValue = dataset.data[tooltipItem.index];

                                        return currentValue + '%';
                                    }
                                }
                            }
                        }
                    });
                    window.CTRBarChart = new window.Chart(CTRBarChart, {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [
                                {
                                    data: ctr,
                                    fill: false,
                                    yAxisID: 'y-axis-2',
                                    backgroundColor: '#4185F4',
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            labels: {
                                fontColor: "#000000",
                                fontSize: 12
                            },
                            legend: {
                                display: false
                            },
                            tooltips: {
                                mode: 'index',
                                callbacks: {
                                    label: function (tooltipItem, data) {
                                        var dataset      = data.datasets[tooltipItem.datasetIndex],
                                            currentValue = dataset.data[tooltipItem.index];

                                        return currentValue + '%';
                                    },
                                    title: function () {
                                        return '';
                                    }
                                }
                            },
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero: true
                                    },
                                    id: 'y-axis-2'
                                }],
                                xAxes: [{
                                    ticks: {
                                        fontColor: '#000000',
                                        beginAtZero: true
                                    }
                                }]
                            }
                        }
                    });
                    $('.mp-report-name').css('display', 'block');
                } else {
                    $('.mp-feed-ctr').append('<div class="mp-feed-report-message"><p' +
                        '>' + $.mage.__("There is no data to display for this report.") + '</p></div>');
                }
            }
        }
    });
});
