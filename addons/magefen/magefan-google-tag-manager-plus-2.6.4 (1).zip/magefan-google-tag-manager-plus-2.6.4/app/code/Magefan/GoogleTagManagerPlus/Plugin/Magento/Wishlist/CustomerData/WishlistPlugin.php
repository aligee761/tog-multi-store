<?php
/**
 * Copyright © Magefan (support@magefan.com). All rights reserved.
 * Please visit Magefan.com for license details (https://magefan.com/end-user-license-agreement).
 */

declare(strict_types=1);

namespace Magefan\GoogleTagManagerPlus\Plugin\Magento\Wishlist\CustomerData;

use Magefan\GoogleTagManagerPlus\Plugin\Magento\Checkout\CustomerData\CartPlugin;

class WishlistPlugin extends CartPlugin
{

}
