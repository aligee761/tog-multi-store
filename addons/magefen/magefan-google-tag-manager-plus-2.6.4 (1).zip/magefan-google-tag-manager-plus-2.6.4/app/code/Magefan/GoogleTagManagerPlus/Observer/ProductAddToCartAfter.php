<?php
/**
 * Copyright © Magefan (support@magefan.com). All rights reserved.
 * Please visit Magefan.com for license details (https://magefan.com/end-user-license-agreement).
 */

declare(strict_types=1);

namespace Magefan\GoogleTagManagerPlus\Observer;

use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magefan\GoogleTagManager\Model\Config;
use Magefan\GoogleTagManagerPlus\Api\SessionManagerInterface;
use Magefan\GoogleTagManagerPlus\Api\DataLayer\AddToCartInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class ProductAddToCartAfter implements ObserverInterface
{
    /**
     * @var Config
     */
    private $config;

    /**
     * @var CheckoutSession
     */
    private $checkoutSession;

    /**
     * @var AddToCartInterface
     */
    private $addToCart;

    /**
     * @var SessionManagerInterface
     */
    private $sessionManager;

    /**
     * ProductAddToCartAfter constructor.
     * @param Config $config
     * @param CheckoutSession $checkoutSession
     * @param AddToCartInterface $addToCart
     * @param SessionManagerInterface $sessionManager
     */
    public function __construct(
        Config $config,
        CheckoutSession $checkoutSession,
        AddToCartInterface $addToCart,
        SessionManagerInterface $sessionManager
    ) {
        $this->config = $config;
        $this->checkoutSession = $checkoutSession;
        $this->addToCart = $addToCart;
        $this->sessionManager = $sessionManager;
    }

    /**
     * Set datalayer after add product to cart
     *
     * @param Observer $observer
     * @throws NoSuchEntityException
     */
    public function execute(Observer $observer)
    {
        if ($this->config->isEnabled()) {
            $quoteItem = $observer->getData('quote_item');
            $this->sessionManager->push(
                $this->checkoutSession,
                $this->addToCart->get($quoteItem)
            );
        }
    }
}
