var config = {
    map: {
        '*': {
            'Magento_Translation/js/mage-translation-dictionary': 'Magefan_TranslationPlus/js/mage-translation-dictionary',
            'mageTranslationDictionary': 'Magefan_TranslationPlus/js/mage-translation-dictionary'
        }
    }
};
